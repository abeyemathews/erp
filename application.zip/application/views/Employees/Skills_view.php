
<div class="container">
  <h2>Employees :: Skills</h2>
  <p></p>            
  <table class="table table-striped">
    <thead>
      <tr>
         
        <th>Employee</th>
        <th>Skill</th>
        <th>Details</th>
        <th></th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
        <td>1</td>
        
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
        <td>1</td>

      </tr>
      <tr>
       <td>Mary</td>
        <td>Dooley</td>
        <td>july@example.com</td>
        <td>1</td>

      </tr>
    </tbody>
  </table>
</div>
</body>
</html>

