  
<div class="container">
  <h2>Employees :: Education</h2>
  <p></p>            
  <table class="table table-striped">
    <thead>
      <tr>
        
        <th>Employee</th>
        <th>Qualification</th>
        <th>Institute</th>
        <th>Start Date</th>
        <th>Completed On</th>
        <th>1</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>1</td>
      </tr>
      <tr>
        
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>1</td>
      </tr>
      <tr>
        
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>1</td>
      </tr>
    </tbody>
  </table>
</div>
</body>
</html>

