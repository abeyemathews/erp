
<div class="container">
  <h2>Employees :: Emergency Contacts</h2>
  <p></p>            
  <table class="table table-striped">
    <thead>
      <tr>
         
        <th>Employee</th>
        <th>Name</th>
        <th>Relationship</th>
        <th>Home Phone</th>
        <th>Work Phone</th>
        <th>Mobile Phone</th>
        <th>1</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
        <td>1</td>
        
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
        <td>1</td>

      </tr>
      <tr>
       <td>Mary</td>
        <td>Dooley</td>
        <td>july@example.com</td>
        <td>Mary</td>
        <td>Dooley</td>
        <td>july@example.com</td>
        <td>1</td>

      </tr>
    </tbody>
  </table>
</div>
</body>
</html>

