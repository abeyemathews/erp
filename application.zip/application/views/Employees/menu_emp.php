<nav class="navbar navbar-expand-sm" style="background-color: #e3f2fd;">.
<a class="navbar-brand" href="#"><img src="http://absmedicalengineering.com/abscompany.png" alt="Smiley face" height="42" width="42"></a>
  <!-- Links -->
  <ul class="navbar-nav">
    
    <li class="nav-item">
        <a class="nav-link" href="#">Company</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Department</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Employees</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Attendance</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Leave Applications</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Holidays</a>
    </li>
    </li>
    
    
    
  </ul>
  <!-- Navbar text-->
  <span class="navbar-text">
    
  
  </span>
</nav>




<nav class="navbar navbar-expand-sm">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img src="http://absmedicalengineering.com/abs.png" alt="Smiley face" height="42" width="42"></a>
  <!-- Links -->
  <ul class="navbar-nav">
    

    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="" id="navbardrop" data-toggle="dropdown">
        Employees
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="index">Add</a>
        <a class="dropdown-item" href="index_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="skills_view" id="navbardrop2" data-toggle="dropdown">
        Skills
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="skills">Add</a>
        <a class="dropdown-item" href="skills_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop3" data-toggle="dropdown">
        Education
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="education">Add</a>
        <a class="dropdown-item" href="education_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop4" data-toggle="dropdown">
       Certifications
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="certification">Add</a>
        <a class="dropdown-item" href="certification_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop5" data-toggle="dropdown">
        Languages
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="languages">Add</a>
        <a class="dropdown-item" href="languages_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop6" data-toggle="dropdown">
       Dependents
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="dependents">Add</a>
        <a class="dropdown-item" href="dependents_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop6" data-toggle="dropdown">
       Emergency Contacts
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="emergencycontact">Add</a>
        <a class="dropdown-item" href="emergencycontact_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop6" data-toggle="dropdown">
       Documents
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="education_view">Add</a>
        <a class="dropdown-item" href="education">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
  </ul>
</nav>