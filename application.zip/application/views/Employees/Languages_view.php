  
<div class="container">
  <h2>Employees :: Languages</h2>
  <p></p>            
  <table class="table table-striped">
    <thead>
      <tr>
      
        <th>Employee</th>
        <th>Language</th>
        <th>Reading</th>
        <th>Speaking</th>
        <th>Writing</th>
        <th>Understanding</th>
        <th>1</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>john@example.com</td>
        <td>1</td>
      </tr>
      <tr>

        <td>Moe</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>mary@example.com</td>
        <td>1</td>
      </tr>
      <tr>

        <td>Dooley</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>july@example.com</td>
        <td>1</td>
      </tr>
    </tbody>
  </table>
</div>
</body>
</html>

