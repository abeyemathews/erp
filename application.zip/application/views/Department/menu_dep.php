<nav class="navbar navbar-expand-sm" style="background-color: #e3f2fd;">.
<a class="navbar-brand" href="#"><img src="http://absmedicalengineering.com/abscompany.png" alt="Smiley face" height="42" width="42"></a>
  <!-- Links -->
  <ul class="navbar-nav">
    
    <li class="nav-item">
        <a class="nav-link" href="#">Company</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="department/index_view">Department</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Employees</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Attendance</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Leave Applications</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Holidays</a>
    </li>
    </li>
    
    
    
  </ul>
  <!-- Navbar text-->
  <span class="navbar-text">
    
  
  </span>
</nav>




<nav class="navbar navbar-expand-sm">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img src="http://absmedicalengineering.com/department.png" alt="Smiley face" height="42" width="42"></a>
  <!-- Links -->
  <ul class="navbar-nav">
    

    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="" id="navbardrop" data-toggle="dropdown">
        Department
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="index">Add</a>
        <a class="dropdown-item" href="index_view">View</a>
        <a class="dropdown-item" href="#">Edit</a>
      </div>
    </li>
    
   
  </ul>
</nav>