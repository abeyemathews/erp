<div id="content" class="fluid-container">
  hello how are you
</div>

<script>
$(document).ready(function() {
  // var jsondata=[
  // {id:1,name:'abey'},
  // {id:2,name:'mathew'},
  // ];
  //  var htmltb= myfirstfn(jsondata) ;
    //$('#content').html(htmltb);
    mySnfn();
    
    
});
</script>

<script>
function myfirstfn(tdldata) 
{
//var tablehtml='<table class="table"><tr><td>01</td><td>02</td></tr> <tr><td>03</td><td>04</td></tr></table>';
var temp='';
$.each(tdldata,function( index, value ) {
  //alert( JSON.stringify(value));
  temp=temp+'<tr>'+'<td>'+value.emp_id+'</td>'+'<td>'+value.emp_fname+'</td>'+'</tr>';
 
});
 return '<table class="table">'+temp+'</table>';
//return tablehtml;

}
</script>

<!--<script>
$(document).ready(myfirstfn());
</script>
-->

<script>
function mySnfn(){
$.post("http://absmedicalengineering.com/erp/index.php/employee/empjson",
    {
        
    },
    function(data, status){
        
    var htmltb= myfirstfn(data) ;
    //alert(htmltb);
    $('#content').html(htmltb);
    });}
</script>
